function mostrarTabuada() {
  var numero = prompt("Digite um número para mostrar a tabuada:");

  if (numero === null || numero === "") {
    alert("Você não inseriu um número válido.");
    return;
  }

  numero = parseInt(numero);

  if (isNaN(numero)) {
    alert("Você não inseriu um número válido.");
    return;
  }

  var tabuada = "Tabuada de " + numero + ":\n";

  for (var i = 1; i <= 10; i++) {
    var resultado = numero * i;
    tabuada += numero + " x " + i + " = " + resultado + "\n";
  }

  alert(tabuada);
}

mostrarTabuada();
