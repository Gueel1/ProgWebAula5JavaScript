var n = prompt("Digite um numero");
var total = n/2;

if(n == 0){
    alert("O numero é zero")
}
else if(n & 1){
    alert("Impar");
} else{
    alert("Par");
}